package com.example.vt;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

public class Calculo extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calculadora);

        final Button mais = (Button) findViewById(R.id.mais);
        final Button menos = (Button) findViewById(R.id.menos);
        final Button vezes = (Button) findViewById(R.id.vezes);
        final Button div = (Button) findViewById(R.id.div);
        final EditText numero1 = (EditText) findViewById(R.id.num1);
        final EditText numero2 = (EditText) findViewById(R.id.num2);
        final TextView results = (TextView) findViewById(R.id.results);
        final ImageButton prox = (ImageButton) findViewById(R.id.prox);


        prox.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(getApplicationContext(),calculadora2.class);
                startActivity(intent);


            }
        });



        mais.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {

                                        String nume1 = numero1.getText().toString();
                                        String nume2 = numero2.getText().toString();
                                        if (nume1.isEmpty() || nume2.isEmpty()) {
                                            Toast.makeText(getApplicationContext(), "Digite os números", Toast.LENGTH_LONG).show();
                                            return;
                                        }
                                        double num1 = Double.parseDouble(nume1);
                                        double num2 = Double.parseDouble(nume2);

                                        double resultado = num1 + num2;

                                        results.setText(String.valueOf(resultado));


                                    }
                                });

                            menos.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {

                                    String nume1 = numero1.getText().toString();
                                    String nume2 = numero2.getText().toString();
                                    if (nume1.isEmpty() || nume2.isEmpty()) {
                                        Toast.makeText(getApplicationContext(), "Digite os números", Toast.LENGTH_LONG).show();
                                        return;
                                    }
                                    double num1 = Double.parseDouble(nume1);
                                    double num2 = Double.parseDouble(nume2);

                                    double resultado = num1 - num2;

                                    results.setText(String.valueOf(resultado));


                                }
                            });

                            div.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {

                                    String nume1 = numero1.getText().toString();
                                    String nume2 = numero2.getText().toString();
                                    if (nume1.isEmpty() || nume2.isEmpty()) {
                                        Toast.makeText(getApplicationContext(), "Digite os números", Toast.LENGTH_LONG).show();
                                        return;
                                    }
                                    double num1 = Double.parseDouble(nume1);
                                    double num2 = Double.parseDouble(nume2);

                                    double resultado = (num1 / num2);

                                    results.setText(String.valueOf(resultado));


                                }
                            });

                            vezes.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {

                                    String nume1 = numero1.getText().toString();
                                    String nume2 = numero2.getText().toString();
                                    if (nume1.isEmpty() || nume2.isEmpty()) {
                                        Toast.makeText(getApplicationContext(), "Digite os números", Toast.LENGTH_LONG).show();
                                        return;
                                    }
                                    double num1 = Double.parseDouble(nume1);
                                    double num2 = Double.parseDouble(nume2);

                                    double resultado = (num1 * num2);

                                    results.setText(String.valueOf(resultado));


                                }
                            });


}}
