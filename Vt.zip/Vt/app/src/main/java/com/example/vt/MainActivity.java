package com.example.vt;
import android.view.MenuInflater;
import android.widget.Button;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toolbar;


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button logar = (Button) findViewById(R.id.logar);

        logar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText nome = (EditText) findViewById(R.id.nome);
                EditText senha = (EditText) findViewById(R.id.senha);



                if(nome.getText().toString().equals("lucas")  && senha.getText().toString().equals("123")  )
                {
                    Intent intent = new Intent(getApplicationContext(),Calculo.class);
                    startActivity(intent);
                }else
                {
                    alert ("Login ou Senha Incorreta");
                }
            }



            private void alert(String s)
            {
                AlertDialog.Builder dialogo =
                        new AlertDialog.Builder(MainActivity.this);

                dialogo.setTitle("Logar");
                dialogo.setMessage(s);
                dialogo.setNeutralButton("OK", null);
                dialogo.show();
            }
        });


    }
}
