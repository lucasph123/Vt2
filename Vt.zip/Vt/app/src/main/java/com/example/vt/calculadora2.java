package com.example.vt;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

public class calculadora2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calculadora2);

        final Button raiz = (Button) findViewById(R.id.raiz);
        final Button elev = (Button) findViewById(R.id.elev);
        final Button log = (Button) findViewById(R.id.log);
        final EditText n1 = (EditText) findViewById(R.id.n1);
        final EditText n2 = (EditText) findViewById(R.id.n2);
        final TextView results2 = (TextView) findViewById(R.id.results2);
        final ImageButton back = (ImageButton) findViewById(R.id.voltar);


        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(getApplicationContext(),Calculo.class);
                startActivity(intent);


            }
        });

        raiz.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String nu1 = n1.getText().toString();
                String nu2 = n2.getText().toString();
                if (nu2.isEmpty()) {


                }


                double num1 = Double.parseDouble(nu1);
                double num2 = Double.parseDouble(nu2);
                double resultado = Math.pow(num1,1/num2);

                results2.setText(String.valueOf(resultado));


            }
        });
        log.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String nu1 = n1.getText().toString();
                String nu2 = n2.getText().toString();
                if (nu1.isEmpty() || nu2.isEmpty()) {
                    Toast.makeText(getApplicationContext(), "Digite os números", Toast.LENGTH_LONG).show();
                    return;
                }
                double num1 = Double.parseDouble(nu1);
                double num2 = Double.parseDouble(nu2);

                double resultado = Math.log(num1) / Math.log(num2);

                results2.setText(String.valueOf(resultado));


            }
        });

        elev.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String nu1 = n1.getText().toString();
                String nu2 = n2.getText().toString();
                if (nu1.isEmpty() || nu2.isEmpty()) {

                    Toast.makeText(getApplicationContext(), "Digite os números", Toast.LENGTH_LONG).show();
                    return;
                }
                double num1 = Double.parseDouble(nu1);
                double num2 = Double.parseDouble(nu2);

               double resultado = Math.pow(num1, num2);

                results2.setText(String.valueOf(resultado));


            }
        });







    }
}
